import sys
import sqlite3
from PyQt5.QtCore import Qt
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QDialog

res = []
p = i = o = 0


class MyWidget(QDialog):
    def __init__(self):
        super().__init__(None, Qt.Dialog)
        uic.loadUi('qwer.ui', self)
        self.pushButton.clicked.connect(self.run)
        self.second_form = SecondForm()

    def run(self):
        self.second_form.show()


class SecondForm(QDialog):
    def __init__(self):
        super().__init__(None, Qt.Dialog)
        uic.loadUi('qaz.ui', self)
        self.radioButton_1.clicked.connect(self.rb1)
        self.radioButton_2.clicked.connect(self.rb2)
        self.radioButton_3.clicked.connect(self.rb3)
        self.radioButton_4.clicked.connect(self.rb4)
        self.second_for1 = SecondForm1()
        self.second_for5 = SecondForm5()
        self.second_for3 = SecondForm3()
        self.second_for4 = SecondForm9()

    def rb1(self):
        self.second_for1.show()

    def rb2(self):
        self.second_for5.show()

    def rb3(self):
        self.second_for3.show()

    def rb4(self):
        self.second_for4.show()


class SecondForm9(QDialog):
    def __init__(self):
        super().__init__(None, Qt.Dialog)
        global res, p, o, i
        self.p = p
        self.o = o
        self.i = i
        uic.loadUi('resultats.ui', self)
        con = sqlite3.connect('films1.db')
        cur = con.cursor()
        result = cur.execute("""SELECT * FROM Films
        WHERE id > -1""").fetchall()
        for elem in result:
            res.append(elem[1])
        con.commit()
        if res[0] > 0:
            self.p += 6
        if res[1] > 0:
            self.p += 6
        if res[2] > 0:
            self.p += 6
        if res[3] > 0:
            self.o += 6
        if res[4] > 0:
            self.o += 6
        if res[5] > 0:
            self.o += 6
        if res[6] > 0:
            self.i += 6
        if res[7] > 0:
            self.i += 6
        res = []
        self.lineEdit.setText(str(self.p + self.o + self.i))
        self.lineEdit_3.setText(str(self.p))
        self.lineEdit_5.setText(str(self.o))
        self.lineEdit_7.setText(str(self.i))
        self.pushButton.clicked.connect(self.hello66)
        self.pushButton_2.clicked.connect(self.vikluchenie)

    def vikluchenie(self):
        self.second_form222 = SecondForm()
        self.second_form222.show()

    def hello66(self):
        con = sqlite3.connect('films1.db')
        cur = con.cursor()
        cur.execute("""UPDATE films
        SET resul = 0
            WHERE id != 999999""")
        con.commit()
        self.second_form223 = SecondForm()
        self.second_form223.show()


class SecondForm1(QDialog):
    def __init__(self):
        super().__init__(None, Qt.Dialog)
        uic.loadUi('a1.ui', self)
        self.pushButton.clicked.connect(self.hello)
        self.pushButton_2.clicked.connect(self.vikluchenie)

    def hello(self):
        global res
        if self.otvet1.text() == '14' and self.otvet2.text() == '243':
            if self.otvet3.text() == '89' and self.otvet4.text() == '32243':
                if self.otvet5.text() == '52' and self.otvet6.text() == '13М':
                    con = sqlite3.connect('films1.db')
                    cur = con.cursor()
                    cur.execute("""UPDATE films
                    SET resul = 1
                        WHERE id == 0""")
                    con.commit()
                    self.second_for5 = SecondForm12()
                    self.second_for5.show()
        if self.otvet1.text() != '14':
            self.otvet1.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet1.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet2.text() != '243':
            self.otvet2.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet2.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet3.text() != '89':
            self.otvet3.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet3.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet4.text() != '32243':
            self.otvet4.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet4.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet5.text() != '52':
            self.otvet5.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet5.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet6.text() != '13М':
            self.otvet6.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet6.setStyleSheet("background-color: rgb(25, 255, 25)")

    def vikluchenie(self):
        self.second_form = SecondForm()
        self.second_form.show()


class SecondForm5(QDialog):
    def __init__(self):
        super().__init__(None, Qt.Dialog)
        uic.loadUi('a2.ui', self)
        self.pushButton.clicked.connect(self.hello1)
        self.pushButton_2.clicked.connect(self.vikluchenie)

    def hello1(self):
        global res
        if self.otvet1.text() == 'Г' and self.otvet2.text() == 'Б':
            if self.otvet3.text() == 'Г' and self.otvet4.text() == 'В':
                if self.otvet5.text() == 'Г' and self.otvet6.text() == 'В':
                    con = sqlite3.connect('films1.db')
                    cur = con.cursor()
                    cur.execute("""UPDATE films
                    SET resul = 1
                        WHERE id == 3""")
                    con.commit()
                    self.second_for5 = SecondForm6()
                    self.second_for5.show()

        if self.otvet1.text() != 'Г':
            self.otvet1.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet1.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet2.text() != 'Б':
            self.otvet2.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet2.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet3.text() != 'Г':
            self.otvet3.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet3.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet4.text() != 'В':
            self.otvet4.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet4.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet5.text() != 'Г':
            self.otvet5.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet5.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet6.text() != 'В':
            self.otvet6.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet6.setStyleSheet("background-color: rgb(25, 255, 25)")

    def vikluchenie(self):
        self.second_form = SecondForm()
        self.second_form.show()


class SecondForm3(QDialog):
    def __init__(self):
        super().__init__(None, Qt.Dialog)
        uic.loadUi('a3.ui', self)
        self.pushButton.clicked.connect(self.hello5)

    def hello5(self):
        self.second_form7 = SecondForm4()
        self.second_form7.show()


class SecondForm4(QDialog):
    def __init__(self):
        super().__init__(None, Qt.Dialog)
        uic.loadUi('a4.ui', self)
        self.pushButton.clicked.connect(self.hello3)
        self.pushButton_2.clicked.connect(self.vikluchenie)
        self.second_form = SecondForm()

    def hello3(self):
        global res
        if self.otvet1.text() == 'нет' and self.otvet2.text() == 'да':
            if self.otvet3.text() == 'да' and self.otvet4.text() == 'нет':
                if self.otvet5.text() == 'нет' and self.otvet6.text() == 'нет':
                    con = sqlite3.connect('films1.db')
                    cur = con.cursor()
                    cur.execute("""UPDATE films
                    SET resul = 1
                        WHERE id == 6""")
                    con.commit()
                    self.second_for5 = SecondForm90()
                    self.second_for5.show()
        if self.otvet1.text() != 'нет':
            self.otvet1.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet1.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet2.text() != 'да':
            self.otvet2.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet2.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet3.text() != 'да':
            self.otvet3.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet3.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet4.text() != 'нет':
            self.otvet4.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet4.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet5.text() != 'нет':
            self.otvet5.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet5.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet6.text() != 'нет':
            self.otvet6.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet6.setStyleSheet("background-color: rgb(25, 255, 25)")

    def vikluchenie(self):
        self.second_form.show()


class SecondForm12(QDialog):
    def __init__(self):
        super().__init__(None, Qt.Dialog)
        uic.loadUi('a12.ui', self)
        self.pushButton.clicked.connect(self.hello12)
        self.pushButton_2.clicked.connect(self.vikluchenie)
        self.second_form = SecondForm()
        self.second_for12 = SecondForm121()

    def hello12(self):
        global res
        if self.otvet1.text() == '91010910' and self.otvet2.text() == '49':
            if self.otvet3.text() == '16' and self.otvet4.text() == '1701':
                if self.otvet5.text() == '8' and self.otvet6.text() == 'АВЕИН':
                    con = sqlite3.connect('films1.db')
                    cur = con.cursor()
                    cur.execute("""UPDATE films
                    SET resul = 1
                        WHERE id == 1""")
                    con.commit()
                    self.second_for5 = SecondForm121()
                    self.second_for5.show()
        if self.otvet1.text() != '91010910':
            self.otvet1.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet1.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet2.text() != '49':
            self.otvet2.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet2.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet3.text() != '16':
            self.otvet3.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet3.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet4.text() != '1701':
            self.otvet4.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet4.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet5.text() != '8':
            self.otvet5.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet5.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet6.text() != 'АВЕИН':
            self.otvet6.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet6.setStyleSheet("background-color: rgb(25, 255, 25)")

    def vikluchenie(self):
        self.second_form.show()


class SecondForm121(QDialog):
    def __init__(self):
        super().__init__(None, Qt.Dialog)
        uic.loadUi('a121.ui', self)
        self.pushButton.clicked.connect(self.hello120)
        self.pushButton_2.clicked.connect(self.vikluchenie)
        self.second_form = SecondForm()
        self.second_for121 = SecondForm65()

    def hello120(self):
        global res
        if self.otvet1.text() == '2' and self.otvet2.text() == '63':
            if self.otvet3.text() == '(' and self.otvet4.text() == 'fgh':
                if self.otvet5.text() == '2' and self.otvet6.text() == 'П':
                    con = sqlite3.connect('films1.db')
                    cur = con.cursor()
                    cur.execute("""UPDATE films
                    SET resul = 1
                        WHERE id == 2""")
                    con.commit()
                    self.second_for5 = SecondForm65()
                    self.second_for5.show()
        if self.otvet1.text() != '2':
            self.otvet1.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet1.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet2.text() != '63':
            self.otvet2.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet2.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet3.text() != '(':
            self.otvet3.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet3.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet4.text() != 'fgh':
            self.otvet4.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet4.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet5.text() != '2':
            self.otvet5.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet5.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet6.text() != 'П':
            self.otvet6.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet6.setStyleSheet("background-color: rgb(25, 255, 25)")

    def vikluchenie(self):
        self.second_form.show()


class SecondForm65(QDialog):
    def __init__(self):
        super().__init__(None, Qt.Dialog)
        uic.loadUi('zxc.ui', self)
        self.pushButton.clicked.connect(self.vikluchenie)
        self.second_form = SecondForm()

    def vikluchenie(self):
        self.second_form.show()


class SecondForm6(QDialog):
    def __init__(self):
        super().__init__(None, Qt.Dialog)
        uic.loadUi('a20.ui', self)
        self.pushButton.clicked.connect(self.hello120)
        self.pushButton_2.clicked.connect(self.vikluchenie)
        self.second_form = SecondForm()
        self.second_for12 = SecondForm201()

    def hello120(self):
        global res
        if self.otvet1.text() == 'Г' and self.otvet2.text() == 'Г':
            if self.otvet3.text() == 'Б' and self.otvet4.text() == 'А':
                if self.otvet5.text() == 'Б' and self.otvet6.text() == 'А':
                    con = sqlite3.connect('films1.db')
                    cur = con.cursor()
                    cur.execute("""UPDATE films
                    SET resul = 1
                        WHERE id == 4""")
                    con.commit()
                    self.second_for5 = SecondForm201()
                    self.second_for5.show()
        if self.otvet1.text() != 'Г':
            self.otvet1.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet1.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet2.text() != 'Г':
            self.otvet2.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet2.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet3.text() != 'Б':
            self.otvet3.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet3.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet4.text() != 'А':
            self.otvet4.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet4.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet5.text() != 'Б':
            self.otvet5.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet5.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet6.text() != 'А':
            self.otvet6.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet6.setStyleSheet("background-color: rgb(25, 255, 25)")

    def vikluchenie(self):
        self.second_form.show()


class SecondForm90(QDialog):
    def __init__(self):
        super().__init__(None, Qt.Dialog)
        uic.loadUi('a5.ui', self)
        self.pushButton.clicked.connect(self.hello56)
        self.second_form = SecondForm55()

    def hello56(self):
        self.second_form.show()


class SecondForm55(QDialog):
    def __init__(self):
        super().__init__(None, Qt.Dialog)
        uic.loadUi('a55.ui', self)
        self.pushButton.clicked.connect(self.hello12)
        self.pushButton_2.clicked.connect(self.vikluchenie)
        self.second_form = SecondForm()
        self.second_for12 = SecondForm65()

    def hello12(self):
        global res
        if self.otvet1.text() == 'да' and self.otvet2.text() == 'да':
            if self.otvet3.text() == 'нет' and self.otvet4.text() == 'нет':
                if self.otvet5.text() == 'нет' and self.otvet6.text() == 'да':
                    con = sqlite3.connect('films1.db')
                    cur = con.cursor()
                    cur.execute("""UPDATE films
                    SET resul = 1
                        WHERE id == 7""")
                    con.commit()
                    self.second_for5 = SecondForm65()
                    self.second_for5.show()
        if self.otvet1.text() != 'да':
            self.otvet1.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet1.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet2.text() != 'да':
            self.otvet2.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet2.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet3.text() != 'нет':
            self.otvet3.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet3.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet4.text() != 'нет':
            self.otvet4.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet4.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet5.text() != 'нет':
            self.otvet5.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet5.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet6.text() != 'да':
            self.otvet6.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet6.setStyleSheet("background-color: rgb(25, 255, 25)")

    def vikluchenie(self):
        self.second_form.show()


class SecondForm201(QDialog):
    def __init__(self):
        super().__init__(None, Qt.Dialog)
        uic.loadUi('a201.ui', self)
        self.pushButton.clicked.connect(self.hello120)
        self.pushButton_2.clicked.connect(self.vikluchenie)
        self.second_form = SecondForm()
        self.second_for12 = SecondForm65()

    def hello120(self):
        global res
        if self.otvet1.text() == 'А' and self.otvet2.text() == 'Г':
            if self.otvet3.text() == 'Г' and self.otvet4.text() == 'Б':
                if self.otvet5.text() == 'В' and self.otvet6.text() == 'В':
                    con = sqlite3.connect('films1.db')
                    cur = con.cursor()
                    cur.execute("""UPDATE films
                    SET resul = 1
                        WHERE id == 5""")
                    con.commit()
                    self.second_for5 = SecondForm65()
                    self.second_for5.show()
        if self.otvet1.text() != 'А':
            self.otvet1.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet1.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet2.text() != 'Г':
            self.otvet2.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet2.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet3.text() != 'Г':
            self.otvet3.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet3.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet4.text() != 'Б':
            self.otvet4.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet4.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet5.text() != 'В':
            self.otvet5.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet5.setStyleSheet("background-color: rgb(25, 255, 25)")
        if self.otvet6.text() != 'В':
            self.otvet6.setStyleSheet("background-color: rgb(255, 36, 0)")
        else:
            self.otvet6.setStyleSheet("background-color: rgb(25, 255, 25)")

    def vikluchenie(self):
        self.second_form.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())
